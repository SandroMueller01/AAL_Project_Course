using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// TO DO: EMG Connection testing and trying of the code adapting feedback of the EMG and the movement to fucntion proper 
// Arduino Code Doccumentation and testing
// Jan Venemand overleaf document writing
// Adapting of the yeongmi project report 
// Programming of the messrodel interface with sledge who shows the forces... 



public class GameManager : MonoBehaviour
{
    // Public variables for movement settings, editable in the Unity Inspector
    public float speed = 5f;
    public float minY = 1.5f;
    public float maxY = 13f;
    public float minX = -9f;
    public float maxX = 9f;

    // Private variables to track the number of balls of each color
    private int blueBalls = 0;
    private int greenBalls = 0;
    private int redBalls = 0;
    private int yellowBalls = 0;

    private bool ballIsGrabbed = false;
   

    // Arrays for GameObject references, assigned via Unity Inspector
    [SerializeField] private GameObject[] ballsToSpawn;
    [SerializeField] private GameObject[] particleSystems;

    // List to dynamically store spawned balls
    [SerializeField] private List<GameObject> balls = new List<GameObject>();

    // Array for sidewalls GameObjects
    [SerializeField] private GameObject[] sidewalls;

    // Selected ball for movemen
    private GameObject selectedBall;

    // Flag to check if a ball is ready to move
    private bool isReadyToMove = false;

    // List to store balls in the selected column
    List<GameObject> ballsInChosenColumn = new List<GameObject>();

    // Serialized connection to an external device (assumed)
    [SerializeField] private SerialConnection serialConnection;

    // Arrays for predefined positions (snap points) on X and Y axis
    private float[] xSnapPoints = { -7.5f, -4.5f, -1.5f, 1.5f, 4.5f, 7.5f };
    private float[] ySnapPoints = { 1.5f, 3.5f, 5.5f, 7.5f, 9.5f, 11.5f };

    // Indices to track the current position in the snap points arrays
    private int xSnapIndex = 0;
    private int ySnapIndex = 0;

    // Index to keep track of the currently selected column
    private int selectedColumnIndex = 0;


    // Start is called before the first frame update
    void Start()
    {
        // Initialize starting indices based on the object's initial position
        xSnapIndex = System.Array.IndexOf(xSnapPoints, transform.position.x);
        ySnapIndex = System.Array.IndexOf(ySnapPoints, transform.position.y);

        // Set indices to 0 if the initial position is not a predefined snap point
        if (xSnapIndex == -1) xSnapIndex = 0;
        if (ySnapIndex == -1) ySnapIndex = 0;

        // Place balls randomly at the start of the game
        RandomPlacementofBalls(); 
    

    }

    // Update is called once per frame
    void Update()
    {
        // Handles column selection logic
        SelectColumn();

        // Sets the isReadyToMove flag based on player input
        if (Input.GetKey(KeyCode.Space))
        {
            isReadyToMove = true;                                     
        }       
        else
        {
            isReadyToMove = false;
        }

        // Moves the ball if it's ready, otherwise selects the top ball in the column
        if (isReadyToMove)
        {
            MoveBall();

        } else
        {
            ChooseTopBall();
        }


        // Checks and manages the positions of all balls
        checkBallPosition();
    }

    // Randomly places balls at predefined snap points on the game board
    void RandomPlacementofBalls()
    {
        // Iterate through each predefined x position (snap point).
        foreach (var xPosition in xSnapPoints)
        {
            // Spawn 4 balls at each x position.
            for (int i = 0; i < 4; i++)
            {
                // Ensure the total number of balls does not exceed 16.
                if (balls.Count < 16)
                {
                    // Instantiate a new ball with a random color at the specified position.
                    GameObject spawnedBall = Instantiate(ballsToSpawn[GetRandomBallColor()], new Vector3(xPosition, ySnapPoints[i], 0), Quaternion.identity);

                    // Add the spawned ball to the balls list
                    balls.Add(spawnedBall);
                    
                }
              
            }
        }
        Debug.Log(balls.Count + "number of balls");
    }

    // Selects a random color for a ball, ensuring an even distribution of each color.
    private int GetRandomBallColor()
    {
        bool ballNotFound = true; // Flag to continue searching for an appropriate color.
        int currentColor = 0; // Variable to hold the randomly selected color.

        // Loop until a suitable ball color is found that does not exceed the preset limit.
        while (ballNotFound)
        {
            // Randomly select a color index based on the available colors in ballsToSpawn array.
            currentColor = Random.Range(0, ballsToSpawn.Length);

            // Check if the chosen color count is within the limit (less than 4).
            // Increment the count for the chosen color and set flag to false if limit not exceeded.
            switch (currentColor)
            {
                case 0: // Blue color case
                    if (blueBalls < 4)
                    {
                        blueBalls++;
                        ballNotFound = false;
                    }
                    break;
                case 1: // Green color case
                    if (greenBalls < 4)
                    {
                        greenBalls++;
                        ballNotFound = false;
                    }
                    break;
                case 2: // Red color case
                    if (redBalls < 4)
                    {
                        redBalls++;
                        ballNotFound = false;
                    }
                    break;
                case 3: // Yellow color case
                    if (yellowBalls < 4)
                    {
                        yellowBalls++;
                        ballNotFound = false;
                    }
                    break;
            }
        }
        return currentColor; // Return the selected color index.
    }


    // Placeholder function to determine if a color limit has been exceeded.
    // Currently, this function always returns true.
    private bool ColorExceeded()
    {
        // The logic to determine if a color limit has been exceeded should be implemented here.
        return true;
    }


    // Moves the currently selected ball based on player input and game logic.
    void MoveBall()
    {
        float armValue = serialConnection.valueToSend;
        Debug.Log(armValue);
        
        // Check if there is a ball currently selected. 
        if (selectedBall != null)
        {
            // Thresholding for the arm value
            if (armValue > 10f)
            {
                ballIsGrabbed = true;
            }
            if(armValue < 4)
            {
                ballIsGrabbed = false;
            }
            // Move the selected ball upwards to a fixed Y position.
            // Replace '11f' with 'serialConnection.valueToSend' if you want to use data from an external device.

            if (ballIsGrabbed)
            {
                selectedBall.transform.position = new Vector3(selectedBall.transform.position.x, 11, 0f);
            }
            
            // Check for left or right arrow key input to move the ball horizontally.
            if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.LeftArrow))
            {
                // Update the ball's X position to align with the selected column's snap point.
                // This allows the ball to snap to the grid defined by xSnapPoints.
                selectedBall.transform.position = new Vector3(xSnapPoints[selectedColumnIndex], selectedBall.transform.position.y, 0f);
            }
        }
    }



    // Checks the position and color of balls in each column and performs actions based on their arrangement.
    void checkBallPosition()
    {
        // Create a dictionary to hold position and color data for each column.
        Dictionary<int, (List<Vector3> positions, List<Color> colors)> columnData = new Dictionary<int, (List<Vector3> positions, List<Color> colors)>();

        // Iterate through each column based on X snap points.
        for (int columnIndex = 0; columnIndex < xSnapPoints.Length; columnIndex++)
        {
            // Initialize lists to hold positions and colors of balls for the current column.
            List<Vector3> ballPositions = new List<Vector3>();
            List<Color> ballColors = new List<Color>();

            // Iterate through each ball to check if it's within the current column.
            foreach (GameObject ball in balls)
            {
                // Check if the ball's X position falls within the current column's boundaries.
                if (ball.transform.position.x > xSnapPoints[columnIndex] - 2 && ball.transform.position.x < xSnapPoints[columnIndex] + 2)
                {
                    // Add the ball's position and color to the respective lists.
                    ballPositions.Add(ball.transform.position);
                    ballColors.Add(ball.GetComponent<Renderer>().material.color);
                }
            }

            // Save the collected data for the current column in the dictionary.
            columnData[columnIndex] = (ballPositions, ballColors);

            // Check if the column contains at least four balls.
            if (ballColors.Count >= 4)
            {
                // Initialize a flag to track if the top four balls have the same color.
                bool sameColors = true;

                // Compare the colors of the top four balls.
                for (int i = 0; i < 3; i++)
                {
                    if (ballColors[i] != ballColors[i + 1])
                    {
                        // Set the flag to false if any adjacent balls do not match in color.
                        sameColors = false;
                        break;
                    }
                }

                // If the top four balls have the same color, trigger actions for this event.
                if (sameColors)
                {
                    // Start a coroutine to manage the particle system for the matched column.
                    StartCoroutine(ManageParticleSystem(particleSystems[columnIndex]));

                    // Log the occurrence for debugging purposes.
                    Debug.Log("Four balls of the same color are stacked in column " + columnIndex);
                }
            }
        }
    }

    // Selects the highest ball within the currently chosen column.
    void ChooseTopBall()
    {
        // Capture vertical input from the player (up or down arrow keys).
        // This variable is currently unused but can be implemented for vertical navigation.
        float verticalInput = Input.GetKey(KeyCode.UpArrow) ? 1f : Input.GetKey(KeyCode.DownArrow) ? -1f : 0f;

        // Initialize with a very low value to find the highest ball in the column.
        float highestYPosition = float.MinValue;

        // Iterate through all balls to check which ones are inside the chosen column.
        foreach (GameObject ball in balls)
        {
            // Check if the ball's X position is within the boundaries of the selected column.
            if (ball.transform.position.x > xSnapPoints[selectedColumnIndex] - 2 && ball.transform.position.x < xSnapPoints[selectedColumnIndex] + 2)
            {
                // Add the ball to the list if it's within the chosen column.
                ballsInChosenColumn.Add(ball);
            }
        }

        // If there are no balls in the chosen column, set the selected ball to null.
        if (ballsInChosenColumn.Count == 0)
        {
            selectedBall = null;
        }

        // Iterate through the balls in the chosen column.
        foreach (GameObject ball in ballsInChosenColumn)
        {
            // Ensure the ball object is not null.
            if (ball != null)
            {
                // Find the ball with the highest Y position.
                if (ball.transform.position.y > highestYPosition)
                {
                    // Update the highest Y position and set the ball as the selected ball.
                    highestYPosition = ball.transform.position.y;
                    selectedBall = ball;
                }
            }
        }

        // Clear the list for the next update cycle.
        ballsInChosenColumn.Clear();
    }


    // Handles the selection of a column based on user input.
    void SelectColumn()
    {
        // Check if the left arrow key is pressed.
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            // If the currently selected column is not the first one,
            // move the selection one column to the left.
            if (selectedColumnIndex > 0)
            {
                selectedColumnIndex--;
            }
        }

        // Check if the right arrow key is pressed.
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            // If the currently selected column is not the last one,
            // move the selection one column to the right.
            if (selectedColumnIndex < xSnapPoints.Length - 1)
            {
                selectedColumnIndex++;
            }
        }

        // Highlight the walls adjacent to the currently selected column.
        // This visually indicates which column is currently active or selected.
        ColorAdjacentColumnWalls(selectedColumnIndex);
    }


    float GetNextXSnapPoint()
    {
        return xSnapPoints[xSnapIndex];
    }

    float GetNextYSnapPoint()
    {
        return ySnapPoints[ySnapIndex];
    }

    void JumpToPreviousXSnapPoint()
    {
        xSnapIndex = (xSnapIndex - 1 + xSnapPoints.Length) % xSnapPoints.Length;
    }

    void JumpToNextXSnapPoint()
    {
        xSnapIndex = (xSnapIndex + 1) % xSnapPoints.Length;
    }

    void JumpToPreviousYSnapPoint()
    {
        ySnapIndex = (ySnapIndex - 1 + ySnapPoints.Length) % ySnapPoints.Length;
    }
    
    void JumpToNextYSnapPoint()
    {
        ySnapIndex = (ySnapIndex + 1) % ySnapPoints.Length;
    }

    // Colors the walls adjacent to a selected column.
    void ColorAdjacentColumnWalls(int columnIndex)
    {
        // Retrieve the left and right walls adjacent to the selected column.
        GameObject sideWallLeft = sidewalls[columnIndex];
        GameObject sideWallRight = sidewalls[columnIndex + 1];

        // Reset the color of all sidewalls to white.
        // This ensures that only the adjacent walls of the selected column are highlighted.
        foreach (GameObject sideWall in sidewalls)
        {
            sideWall.GetComponent<Renderer>().material.color = Color.white;
        }

        // Color the left adjacent wall of the selected column blue.
        sideWallLeft.GetComponent<Renderer>().material.color = Color.blue;

        // Color the right adjacent wall of the selected column blue.
        sideWallRight.GetComponent<Renderer>().material.color = Color.blue;
    }


    // Coroutine to manage the activation and deactivation of a particle system.
    IEnumerator ManageParticleSystem(GameObject particleSystem)
    {
        // Activate the particle system.
        particleSystem.SetActive(true);

        // Wait for 5 seconds. During this time, the particle effect will be visible.
        yield return new WaitForSeconds(5f);

        // After 5 seconds, deactivate the particle system.
        particleSystem.SetActive(false);
    }


}
