using UnityEngine;
using System.IO.Ports;
using System.Threading;

public class SerialConnection : MonoBehaviour
{
    private SerialPort serialPort;
    private Thread dataThread; // Thread for handling data
    private bool isRunning = true; // Flag to control the thread
    public string comPortName = "COM4"; // Change this to the desired COM port
    public int baudRate = 19200; // Adjust the baud rate as needed for your device
    public float valueToSend;
    private float currentValue = 0;
    private float previousValue;
    
    private bool EMGFlag = false;

    void Start()
    {
        serialPort = new SerialPort(comPortName, baudRate);

        try
        {
            serialPort.Open();
            serialPort.ReadTimeout = 10000;
            Debug.Log("Serial port connection established.");

            // Start the data thread
            dataThread = new Thread(ReadData);
            dataThread.Start();
        }
        catch (System.Exception ex)
        {
            Debug.LogError("Failed to open serial port: " + ex.Message);
        }
    }

    void OnDestroy()
    {
        isRunning = false; // Stop the data thread
        if (dataThread != null && dataThread.IsAlive)
        {
            dataThread.Join(); // Wait for the thread to finish
        }

        if (serialPort != null && serialPort.IsOpen)
        {
            serialPort.Close();
        }
    }

    void ReadData()
    {
        while (isRunning)
        {
            // read data from serial port
            if (serialPort != null && serialPort.IsOpen)
            {
                try
                {
                    string data = serialPort.ReadLine();

                    if (data.Contains("Motor-Encoder:"))
                    {
                        string[] parts = data.Split(':');

                        // Ensure there are at least two parts (prefix and number)
                        if (parts.Length >= 2)
                        {
                            string numberStr = parts[1].Trim();

                            // Convert the number string to an integer (you can use int.TryParse for error handling)
                            if (int.TryParse(numberStr, out int encoderValue))
                            {   
                                // Call your next function and pass the encoder value as a parameter
                                Debug.Log("Encoder value: " + encoderValue);
                                processEncoderData(encoderValue);
                            }
                        }
                    }

                    else if (data.Contains("EMG-Value"))
                    {
                        string[] parts = data.Split(':');

                        if (parts.Length >= 2)
                        {
                            string numberStr = parts[1].Trim();

                            // Convert the number string to an integer (you can use int.TryParse for error handling)
                            if (int.TryParse(numberStr, out int emgValue))
                            {
                                
                                // Call your next function and pass the encoder value as a parameter
                                processEMGData(emgValue);
                            }
                        }
                    }
                   
                }
                catch (System.Exception ex)
                {
                    Debug.LogError("Serial port read error: " + ex.Message);
                }
            }
        }
    }

    void processEncoderData(int encoderValue)
    {
        // Log the original encoder value
        Debug.Log("Original Encoder Value: " + encoderValue);

        // Define the input range and the output range
        float inputMin = 330.0f;
        float inputMax = 520.0f;
        float outputMin = 0.0f;
        float outputMax = 11.0f;

        // Calculate the scaling factor (S)
        float scaling = (outputMax - outputMin) / (inputMax - inputMin);

        // Calculate the offset (O)
        float offset = outputMin - scaling * inputMin;

        // Map the encoderValue to the desired range (0-11)
        float mappedValue = scaling * encoderValue + offset;

        // Clamp the mapped value to ensure it's within 0 to 11
        mappedValue = Mathf.Clamp(mappedValue, 0, 11);

        // Log the mapped value
        Debug.Log("Mapped Value: " + mappedValue);

        // Set the value to send
        valueToSend = mappedValue;
    }



    void processEMGData(int EMGValue)
    {
        // Processing of the encoder value goes here, value is an integer
   

        if (EMGValue > 500 && !EMGFlag) // Thresholding value of EMG Sensor
        {
            //EMGDetect = true;
            EMGFlag = true;
        }
        else if (EMGValue > 500 && EMGFlag)
        {
            //EMGDetect = false;
            EMGFlag = false;
        }
    }

    void sendToArduino(string message)
    {
        if (serialPort != null && serialPort.IsOpen)
        {
            try
            {
                serialPort.WriteLine(message);
                Debug.Log("Sent data to COM port.");
            }
            catch (System.Exception ex)
            {
                Debug.LogError("Serial port write error: " + ex.Message);
            }
        }
    }
}
